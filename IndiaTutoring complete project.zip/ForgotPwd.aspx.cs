﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;

namespace IndiaTutoring
{
    public partial class ForgotPwd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnForgot_Click(object sender, EventArgs e)
        {
           string email = txtPEmail.Text.Trim();

            // Check if the email exists in the database
            if (CheckIfEmailExists(email))
            {
                // Generate a unique reset token (you can use a library like Guid.NewGuid() for this)
                string resetToken = GenerateResetToken();

                // Save the reset token and its expiration time to the database for the user
                SaveResetTokenToDatabase(email, resetToken);

                // Send the reset password link to the user's email
                SendResetPasswordEmail(email, resetToken);

                lblPEmail.Text = "A password reset link has been sent to your email.";
            }
            else
            {
                lblPEmail.Text = "Email address not found. Please enter the registered email.";
            }

            lblPEmail.Visible = true;

        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }       
        private bool CheckIfEmailExists(string email)
        {
            // Replace "YourConnectionString" with your actual database connection string
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString))
            {
                con.Open();

                SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM NEWACCOUNT WHERE EMAIL = @EMAIL", con);
                command.Parameters.AddWithValue("@EMAIL", email);

                int count = (int)command.ExecuteScalar();
                return count > 0;
            }
        }
        private string GenerateResetToken()
        {
            // You can use any method to generate a unique reset token (e.g., Guid.NewGuid())
            return Guid.NewGuid().ToString();
        }
        private void SaveResetTokenToDatabase(string email, string resetToken)
        {
            // Replace "YourConnectionString" with your actual database connection string
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ConnectionString))
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("UPDATE NEWACCOUNT SET ResetToken = @ResetToken, ResetTokenExpiry = @ResetTokenExpiry WHERE Email = @Email", con);
                    cmd.Parameters.AddWithValue("@ResetToken", resetToken);
                    cmd.Parameters.AddWithValue("@ResetTokenExpiry", DateTime.Now.AddHours(1).ToString("yyyy-MM-dd HH:mm:ss")); // Make sure the format matches your database
                    cmd.Parameters.AddWithValue("@Email", email);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                // Handle the exception appropriately, you can log it or display an error message to the user.
                lblPEmail.Text = "An error occurred while saving the reset token. Please try again later.";
                lblPEmail.Visible = true;
            }
        }
        private void SendResetPasswordEmail(string email, string resetToken)
        {
            // Replace "YourEmail@gmail.com" and "YourPassword" with your email credentials
            string fromEmail = "Indianfutureeducationalacademy@gmail.com";
            string fromPassword = "Indian123@";

            // Replace "YourDomain.com" with the domain name of your website
            string resetLink = $"https://indianfutureeduacademy.bsite.net/ForgotPwd.aspx?token={resetToken}";

            MailMessage message = new MailMessage(fromEmail, email)
            {
                Subject = "Password Reset Link",
                Body = $"Click on the following link to reset your password: {resetLink}",
                IsBodyHtml = true
            };

            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587)
            {
                Credentials = new NetworkCredential(fromEmail, fromPassword),
                EnableSsl = true
            };
            try
            {
                smtpClient.Send(message);
                // If the email is sent successfully, you can add a success message or take other actions if needed.
                // For example: lblMessage.Text = "A password reset link has been sent to your email.";
            }
            catch (Exception ex)
            {
                // Handle the exception appropriately, you can log it or display an error message to the user.
                // For example:
                lblPEmail.Text = "An error occurred while sending the email. Please try again later.";
                // Log the exception for troubleshooting purposes
                // Logging can be done using a logging library or simply writing to a log file.
                // Example log message: Log.Write("Error sending reset password email: " + ex.ToString());
            }           
        }
    }
}






