﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
namespace IndiaTutoring
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string uid = txtUName.Text;
                string pass = txtPwd.Text;
                string qry = "SELECT*FROM NEWACCOUNT WHERE USERNAME='" + uid + "' AND PASSWORD='" + pass + "' ";
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString());
                con.Open();
                SqlDataAdapter adpt = new SqlDataAdapter(qry, con);
                DataTable dt = new DataTable();
                adpt.Fill(dt);
                if (dt.Rows.Count == 1)
                {
                    Session["user"] = uid;
                    if (dt.Rows[0]["position"].ToString() == "admin")
                    {
                        Response.Redirect("~/ADMIN/AdminHome.aspx");
                    }
                    else if (dt.Rows[0]["position"].ToString() == "user")
                    {
                        Response.Redirect("~/User/indexpage.aspx");
                    }
                }
                else
                {
                    lblMsg.Text = "Invalid username & password";
                    lblMsg.ForeColor = Color.Red;

                    //if (srd.Read())
                    //{
                    //    lblMsg.Text = "Login success..";
                    //    lblMsg.ForeColor = Color.Green;
                    //}
                    //else
                    //{
                    //    lblMsg.Text = "Invalid username & password";
                    //    lblMsg.ForeColor = Color.Red;
                    //}
                }
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}