﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IndiaTutoring.USER
{
    public partial class Exam : System.Web.UI.Page
    {
        private Dictionary<string, Dictionary<string, string>> pdfMappings = new Dictionary<string, Dictionary<string, string>>()
        {
            { "SSC", new Dictionary<string, string>() {
                { "3", "~/Result PDF/SSC/dummy.pdf" },
                { "4", "~/Result PDF/SSC/dummy.pdf" },
                { "5", "~/Result PDF/SSC/dummy.pdf" },
                { "6", "~/Result PDF/SSC/dummy.pdf" },
                { "7", "~/Result PDF/SSC/dummy.pdf" },
                { "8", "~/Result PDF/SSC/dummy.pdf" },
                { "9", "~/Result PDF/SSC/dummy.pdf" },
                { "10", "~/Result PDF/SSC/dummy.pdf" },
                { "11", "~/Result PDF/SSC/dummy.pdf" },
                { "12", "~/Result PDF/SSC/dummy.pdf" },
            }},
            { "CBSC", new Dictionary<string, string>() {
                { "3", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "4", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "5", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "6", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "7", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "8", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "9", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "10", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "11", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "12", "~/Result PDF/CBSC/Get_Started_With_Smallpdf.pdf" }
            }},
            { "ICSC", new Dictionary<string, string>() {
                { "3", "~/Result PDF/ICSC/sample.pdf" },
                { "4", "~/Result PDF/ICSC/sample.pdf" },
                { "5", "~/Result PDF/ICSC/sample.pdf" },
                { "6", "~/Result PDF/ICSC/sample.pdf" },
                { "7", "~/Result PDF/ICSC/sample.pdf" },
                { "8", "~/Result PDF/ICSC/sample.pdf" },
                { "9", "~/Result PDF/ICSC/sample.pdf" },
                { "10", "~/Result PDF/ICSC/sample.pdf" },
                { "11", "~/Result PDF/ICSC/sample.pdf" },
                { "12", "~/Result PDF/ICSC/sample.pdf" }

            }},
        };
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string selectedBoard = ddlBoard.SelectedValue;
            string grade = txtGrade.Text;

            if (pdfMappings.ContainsKey(selectedBoard) && pdfMappings[selectedBoard].ContainsKey(grade))
            {
                string pdfFilePath = pdfMappings[selectedBoard][grade];
                pdfViewer.Src = pdfFilePath; // Set the PDF file path to the iframe
            }
            else
            {
                // Handle case when no PDF file is available
                // You can display an error message or redirect to a default page
            }
        }
    }
}