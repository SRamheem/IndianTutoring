﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;

namespace IndiaTutoring.USER
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            //try
            //{
                string fname = txtFName.Text;
                string lname = txtLName.Text;
                string username = txtUser.Text;
                string pwd = txtPwd.Text;
                string email = txtEmail.Text;
                string location = txtLocation.Text;

                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString()))
                {
                    con.Open();
                    string qry = "INSERT INTO NEWACCOUNT (FIRSTNAME, LASTNAME, USERNAME, PASSWORD, EMAIL, LOCATION, POSITION) VALUES (@FIRSTNAME, @LASTNAME, @USERNAME, @PASSWORD, @EMAIL, @LOCATION, 'user')";
                    SqlCommand cmd = new SqlCommand(qry, con);
                    cmd.Parameters.AddWithValue("@FIRSTNAME", fname);
                    cmd.Parameters.AddWithValue("@LASTNAME", lname);
                    cmd.Parameters.AddWithValue("@USERNAME", username);
                    cmd.Parameters.AddWithValue("@PASSWORD", pwd);  // Ensure password hashing/salting before storing
                    cmd.Parameters.AddWithValue("@EMAIL", email);
                    cmd.Parameters.AddWithValue("@LOCATION", location);

                    int i = cmd.ExecuteNonQuery();
                    if (i > 0)
                    {
                        update();
                        Response.Redirect("Welcome.aspx");
                    }
                    else
                    {
                        Label1.Text = "Error";
                    }
                }
            //}
            //catch (Exception ex)
            //{
            //    // Handle the exception and display an appropriate error message.
            //    Label1.Text = "An error occurred while processing your request. Please try again later.";
            //    Label1.ForeColor = Color.Red;
            //}
        }
        public void update()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString()))
                {
                    con.Open();
                    SqlDataAdapter sda = new SqlDataAdapter("SELECT SINO FROM NEWACCOUNT WHERE EMAIL='" + txtEmail.Text + "'", con);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    if (dt.Rows.Count == 1)
                    {
                        string id = dt.Rows[0]["SINO"].ToString();
                        string genid = txtFName.Text.ToString() + txtLName.Text.ToString() + id.ToString();
                        string sql = "UPDATE NEWACCOUNT SET USER_ID='" + genid + "' WHERE SINO='" + id + "' ";
                        SqlCommand cmd2 = new SqlCommand(sql, con);
                        cmd2.ExecuteNonQuery();

                        Label1.Text = "Account created successfully....";
                        Label1.ForeColor = Color.Green;
                    }
                    else
                    {
                        Response.Redirect("~/USER/NewAccount.aspx");
                        Label1.Text = "Account not created...";
                        Label1.ForeColor = Color.Red;
                    }
                }
            }
            catch (Exception ex)
            {
                //    // Handle the exception and display an appropriate error message.
                //    Label1.Text = "An error occurred while updating the account. Please try again later.";
                //    Label1.ForeColor = Color.Red;
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["mycon"].ToString()))
                {
                    con.Open();
                    SqlCommand cmd3 = new SqlCommand("SELECT USERNAME FROM NEWACCOUNT WHERE USERNAME=@USERNAME", con);
                    cmd3.Parameters.AddWithValue("@USERNAME", txtUser.Text);
                    SqlDataReader dr = cmd3.ExecuteReader();
                    if (dr.HasRows)
                    {
                        lblCheck.Text = "Not Available";
                        lblCheck.ForeColor = Color.Red;
                        btnRegister.Visible = false;
                    }
                    else
                    {
                        lblCheck.Text = "User Name Available";
                        lblCheck.ForeColor = Color.Green;
                        btnRegister.Visible = true;
                    }
                }
            }
            catch(Exception ex)
            {
                //Handle the exception and display an appropriate error message.
                lblCheck.Text = "An error occurred while checking the username availability. Please try again later.";
                lblCheck.ForeColor = Color.Red;
                btnRegister.Visible = false;
            }
        }
        protected void btnReset_Click(object sender, EventArgs e)
        {
            txtFName.Text = txtLName.Text = txtEmail.Text = txtPwd.Text = txtUser.Text = txtLocation.Text = "";
        }
    }
}
