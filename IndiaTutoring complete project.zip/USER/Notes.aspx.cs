﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PdfiumViewer;

namespace IndiaTutoring.USER
{
   
    public partial class Notes : System.Web.UI.Page
    {
        private Dictionary<string, Dictionary<string, string>> pdfMappings = new Dictionary<string, Dictionary<string, string>>()
        {
            { "SSC", new Dictionary<string, string>() {
                { "3", "~/Board/SSC/dummy.pdf" },
                { "4", "~/Board/SSC/dummy.pdf" },
                { "5", "~/Board/SSC/dummy.pdf" },
                { "6", "~/Board/SSC/dummy.pdf" },
                { "7", "~/Board/SSC/dummy.pdf" },
                { "8", "~/Board/SSC/dummy.pdf" },
                { "9", "~/Board/SSC/dummy.pdf" },
                { "10", "~/Board/SSC/dummy.pdf" },
                { "11", "~/Board/SSC/dummy.pdf" },
                { "12", "~/Board/SSC/dummy.pdf" },
            }},
            { "CBSC", new Dictionary<string, string>() {
                { "3", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "4", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "5", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "6", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "7", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "8", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "9", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "10", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "11", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" },
                { "12", "~/Board/CBSC/Get_Started_With_Smallpdf.pdf" }
            }},
            { "ICSC", new Dictionary<string, string>() {
                { "3", "~/Board/ICSC/sample.pdf" },
                { "4", "~/Board/ICSC/sample.pdf" },
                { "5", "~/Board/ICSC/sample.pdf" },
                { "6", "~/Board/ICSC/sample.pdf" },
                { "7", "~/Board/ICSC/sample.pdf" },
                { "8", "~/Board/ICSC/sample.pdf" },
                { "9", "~/Board/ICSC/sample.pdf" },
                { "10", "~/Board/ICSC/sample.pdf" },
                { "11", "~/Board/ICSC/sample.pdf" },
                { "12", "~/Board/ICSC/sample.pdf" }

            }},
        };
        protected void Page_Load(object sender, EventArgs e)
        {

        }      

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string selectedBoard = ddlBoard.SelectedValue;
            string grade = txtGrade.Text;

            if (pdfMappings.ContainsKey(selectedBoard) && pdfMappings[selectedBoard].ContainsKey(grade))
            {
                string pdfFilePath = pdfMappings[selectedBoard][grade];
                pdfViewer.Src = pdfFilePath; // Set the PDF file path to the iframe
            }
            else
            {
                // Handle case when no PDF file is available
                // You can display an error message or redirect to a default page
            }
        }
    }
}


