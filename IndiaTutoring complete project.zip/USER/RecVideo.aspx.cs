﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace IndiaTutoring.USER
{
    public partial class RecVideo : System.Web.UI.Page
    {
        private Dictionary<string, Dictionary<string, string>> videoMappings = new Dictionary<string, Dictionary<string, string>>()
        {
            { "SSC", new Dictionary<string, string>() {
                { "3", "~/RecVideo/SSC/sample2.mp4" },
                { "4", "~/RecVideo/SSC/sample2.mp4" },
                { "5", "~/RecVideo/SSC/sample2.mp4" },
                { "6", "~/RecVideo/SSC/sample2.mp4" },
                { "7", "~/RecVideo/SSC/sample2.mp4" },
                { "8", "~/RecVideo/SSC/sample2.mp4" },
                { "9", "~/RecVideo/SSC/sample2.mp4" },
                { "10", "~/RecVideo/SSC/sample2.mp4" },
                { "11", "~/RecVideo/SSC/sample2.mp4" },
                { "12", "~/RecVideo/SSC/sample2.mp4" }
            }},
            { "CBSC", new Dictionary<string, string>() {
                { "3", "~/RecVideo/CBSC/sample1.mp4" },
                { "4", "~/RecVideo/CBSC/sample1.mp4" },
                { "5", "~/RecVideo/CBSC/sample1.mp4" },
                { "6", "~/RecVideo/CBSC/sample1.mp4" },
                { "7", "~/RecVideo/CBSC/sample1.mp4" },
                { "8", "~/RecVideo/CBSC/sample1.mp4" },
                { "9", "~/RecVideo/CBSC/sample1.mp4" },
                { "10", "~/RecVideo/CBSC/sample1.mp4" },
                { "11", "~/RecVideo/CBSC/sample1.mp4" },
                { "12", "~/RecVideo/CBSC/sample1.mp4" },
            }},
            { "ICSC", new Dictionary<string, string>() {
                { "3", "~/RecVideo/ICSC/sample2.mp4" },
                { "4", "~/RecVideo/ICSC/sample2.mp4" },
                { "5", "~/RecVideo/ICSC/sample2.mp4" },
                { "6", "~/RecVideo/ICSC/sample2.mp4" },
                { "7", "~/RecVideo/ICSC/sample2.mp4" },
                { "8", "~/RecVideo/ICSC/sample2.mp4" },
                { "9", "~/RecVideo/ICSC/sample2.mp4" },
                { "10", "~/RecVideo/ICSC/sample2.mp4" },
                { "11", "~/RecVideo/ICSC/sample2.mp4" },
                { "12", "~/RecVideo/ICSC/sample2.mp4" },
            }},
        };
        protected void Page_Load(object sender, EventArgs e)
        {

        }      

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string selectedBoard = ddlBoard.SelectedValue;
            string grade = txtGrade.Text;

            if (videoMappings.ContainsKey(selectedBoard) && videoMappings[selectedBoard].ContainsKey(grade))
            {
                string videoFilePath = videoMappings[selectedBoard][grade];
                videoSource.Src = videoFilePath;
                ClientScript.RegisterStartupScript(this.GetType(), "ShowVideoPlayer", "showVideoPlayer();", true);
            }
            else
            {
                // Handle case when no video file is available
                // You can display an error message or redirect to a default page
            }
        }
    }
}